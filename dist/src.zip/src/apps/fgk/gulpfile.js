const scripts = require('../../common/scripts/gulp/scripts');

scripts('fgk');
